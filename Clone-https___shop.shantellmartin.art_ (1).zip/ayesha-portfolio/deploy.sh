#!/bin/sh

# Build the project
echo "Building your portfolio..."
npm run build || { echo "Build failed"; exit 1; }

# Add .nojekyll file to bypass Jekyll processing
touch out/.nojekyll

# If you're deploying to a custom domain
# echo "yourdomain.com" > out/CNAME

# Deploy to GitHub Pages
echo "Deploying to GitHub Pages..."
npm run deploy || { echo "Deployment failed"; exit 1; }

echo "🎉 Your portfolio has been deployed successfully!"
echo "Please allow a few minutes for the changes to be reflected at https://yourusername.github.io/ayesha-portfolio"
