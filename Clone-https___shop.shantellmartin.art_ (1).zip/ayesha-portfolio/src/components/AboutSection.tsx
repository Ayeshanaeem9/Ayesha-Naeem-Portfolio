import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function AboutSection() {
  return (
    <section className="py-12 md:py-16 lg:py-20 bg-black text-white">
      <div className="container">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
          <div className="flex flex-col space-y-8">
            <div>
              <h2 className="text-2xl font-bold uppercase tracking-wide md:text-3xl">
                CREATIVE EXPLORATION
              </h2>
            </div>
            <div className="space-y-4">
              <p>
                Ayesha Naeem is a visual artist, curator, and creative director known for her
                distinctive artistic style that bridges traditional and contemporary techniques.
                Her work explores themes of identity, cultural heritage, and human connection.
              </p>
              <p>
                Creating connections between art, culture, and technology, Ayesha explores the
                boundaries between different media while maintaining a cohesive artistic vision.
              </p>
              <p>
                With exhibitions at prominent galleries and museums, Ayesha has established herself
                as a unique voice in contemporary art, bringing a fresh perspective to the creative
                landscape.
              </p>
            </div>
            <div>
              <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-black uppercase tracking-wide">
                <Link href="/about">More about Ayesha</Link>
              </Button>
            </div>
          </div>
          <div className="relative mt-8 lg:mt-0">
            <div className="relative aspect-[4/5] overflow-hidden rounded-md">
              <Image
                src="https://ext.same-assets.com/532912459/2586677189.jpeg"
                alt="Ayesha Naeem portrait"
                fill
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 aspect-square w-32 md:-bottom-8 md:-left-8 md:w-40 lg:w-48">
              <Image
                src="https://ext.same-assets.com/22451986/977723821.jpeg"
                alt="Ayesha Naeem line drawing"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
