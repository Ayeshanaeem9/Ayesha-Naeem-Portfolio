"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AspectRatio } from "@/components/ui/aspect-ratio"
import { Card, CardContent } from "@/components/ui/card"
import { useState } from "react"

interface ArtworkProps {
  artwork: {
    id: string
    title: string
    priceUSD: string
    pricePKR: string
    imageSrc: string
    imageAlt: string
    detailSrc?: string
  }
}

function ArtworkCard({ artwork }: ArtworkProps) {
  const [currency, setCurrency] = useState<'USD' | 'PKR'>('USD');

  return (
    <Card className="overflow-hidden border-none bg-white shadow-sm transition-all hover:shadow-md">
      <CardContent className="p-0">
        <Link href={`/artwork/${artwork.id}`}>
          <div className="overflow-hidden">
            <AspectRatio ratio={1 / 1} className="bg-muted">
              <Image
                src={artwork.imageSrc}
                alt={artwork.imageAlt}
                fill
                className="object-cover object-center transition-transform hover:scale-105"
              />
            </AspectRatio>
          </div>
          <div className="p-4">
            <h3 className="line-clamp-1 text-base font-medium">{artwork.title}</h3>
            <div className="mt-1 flex items-center justify-between">
              <p className="text-sm">{currency === 'USD' ? artwork.priceUSD : artwork.pricePKR}</p>
              <div className="flex text-xs">
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrency('USD');
                  }}
                  className={`px-2 py-1 ${currency === 'USD' ? 'bg-black text-white' : 'bg-gray-100'}`}
                >
                  USD
                </button>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrency('PKR');
                  }}
                  className={`px-2 py-1 ${currency === 'PKR' ? 'bg-black text-white' : 'bg-gray-100'}`}
                >
                  PKR
                </button>
              </div>
            </div>
          </div>
        </Link>
      </CardContent>
    </Card>
  )
}

export function FeaturedArtwork() {
  // Current conversion rate: 1 USD = approximately 278 PKR
  const featuredArtworks = [
    {
      id: "one-lithograph",
      title: "One (Lithograph)",
      priceUSD: "$500.00",
      pricePKR: "₨139,000",
      imageSrc: "https://ext.same-assets.com/1089614442/3456456587.jpeg",
      imageAlt: "One Lithograph artwork by Ayesha Naeem",
      detailSrc: "https://ext.same-assets.com/2008200891/861606857.jpeg"
    },
    {
      id: "two-lithograph",
      title: "Two (Lithograph)",
      priceUSD: "$500.00",
      pricePKR: "₨139,000",
      imageSrc: "https://ext.same-assets.com/581280838/4271405611.jpeg",
      imageAlt: "Two Lithograph artwork by Ayesha Naeem",
      detailSrc: "https://ext.same-assets.com/902569312/3057227048.jpeg"
    },
    {
      id: "three-lithograph",
      title: "Three (Lithograph)",
      priceUSD: "$500.00",
      pricePKR: "₨139,000",
      imageSrc: "https://ext.same-assets.com/2761418991/3500861600.jpeg",
      imageAlt: "Three Lithograph artwork by Ayesha Naeem",
      detailSrc: "https://ext.same-assets.com/2611463085/3714510384.jpeg"
    },
    {
      id: "four-lithograph",
      title: "Four (Lithograph)",
      priceUSD: "$500.00",
      pricePKR: "₨139,000",
      imageSrc: "https://ext.same-assets.com/1847617457/1041322322.jpeg",
      imageAlt: "Four Lithograph artwork by Ayesha Naeem",
      detailSrc: "https://ext.same-assets.com/4233648122/518648900.jpeg"
    },
    {
      id: "five-lithograph",
      title: "Five (Lithograph)",
      priceUSD: "$500.00",
      pricePKR: "₨139,000",
      imageSrc: "https://ext.same-assets.com/3192702198/874570515.jpeg",
      imageAlt: "Five Lithograph artwork by Ayesha Naeem",
      detailSrc: "https://ext.same-assets.com/778484025/3196930716.jpeg"
    },
    {
      id: "six-lithograph",
      title: "Six (Lithograph)",
      priceUSD: "$500.00",
      pricePKR: "₨139,000",
      imageSrc: "https://ext.same-assets.com/2612802310/2992305280.jpeg",
      imageAlt: "Six Lithograph artwork by Ayesha Naeem",
      detailSrc: "https://ext.same-assets.com/1763148113/806376802.jpeg"
    }
  ]

  return (
    <section className="py-12 md:py-16 lg:py-20">
      <div className="container">
        <div className="mb-8 flex flex-col items-center text-center">
          <h2 className="text-3xl font-bold uppercase tracking-tight">For Your Wall</h2>
          <p className="mt-4 max-w-[58rem] text-muted-foreground">
            Ayesha Naeem uses distinctive techniques to create artwork that explores themes
            of identity, creativity, and imagination through bold visual expressions.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredArtworks.map((artwork) => (
            <ArtworkCard key={artwork.id} artwork={artwork} />
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <Button asChild className="uppercase tracking-wide">
            <Link href="/artwork/prints">View All Prints</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
