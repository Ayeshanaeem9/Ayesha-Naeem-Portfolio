import { Hero } from "@/components/Hero"
import { FeaturedArtwork } from "@/components/FeaturedArtwork"
import { AboutSection } from "@/components/AboutSection"

export default function Home() {
  return (
    <div className="flex flex-col">
      <Hero />
      <FeaturedArtwork />
      <AboutSection />
    </div>
  )
}
