# Ayesha Naeem Portfolio

A minimalist artist portfolio website built with Next.js, Tailwind CSS, and TypeScript.

## Features

- Clean, modern design
- Responsive layout for all devices
- Image gallery for artwork
- Dual currency pricing (USD/PKR)
- About page
- Contact form
- Built with Next.js and TypeScript

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v18 or later)
- [Git](https://git-scm.com/)

### Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The site will be available at http://localhost:3000

## Deploying to GitHub Pages

### Option 1: Automatic Deployment (GitHub Actions)

1. Push your code to GitHub
2. GitHub Actions will automatically build and deploy your site
3. Your site will be available at `https://yourusername.github.io/ayesha-portfolio`

### Option 2: Manual Deployment

1. Edit `scripts/deploy.sh` and update your GitHub username
2. Make the script executable: `chmod +x scripts/deploy.sh`
3. Run the deployment script: `./scripts/deploy.sh`

## Customizing Content

### Artwork

To update the artwork:

1. Open `src/components/FeaturedArtwork.tsx`
2. Modify the `featuredArtworks` array:

```jsx
{
  id: "one-lithograph",
  title: "One (Lithograph)",
  priceUSD: "$500.00",
  pricePKR: "₨139,000",
  imageSrc: "your-image-url.jpg",
  imageAlt: "Your alt text",
  detailSrc: "detail-image-url.jpg"
}
```

### Hero Images

1. Open `src/components/Hero.tsx`
2. Update the `images` array with your own images and text

## Adding a Custom Domain

1. Purchase a domain name from a domain registrar
2. Create a `CNAME` file in the `public` directory with your domain name:
   ```
   yourdomain.com
   ```
3. Configure your domain's DNS settings:
   - Type: A, Name: @, Value: 185.199.108.153
   - Type: A, Name: @, Value: 185.199.109.153
   - Type: A, Name: @, Value: 185.199.110.153
   - Type: A, Name: @, Value: 185.199.111.153
   - Type: CNAME, Name: www, Value: yourusername.github.io

## License

This project is licensed under the MIT License.

## Acknowledgments

- [Next.js](https://nextjs.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [shadcn/ui](https://ui.shadcn.com/)
