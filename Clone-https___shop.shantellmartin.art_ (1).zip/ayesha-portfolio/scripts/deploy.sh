#!/bin/bash

# Script to deploy to GitHub Pages

# Change to your GitHub username
GITHUB_USERNAME="your-github-username"
REPO_NAME="ayesha-portfolio"

# Build the project
echo "⚡ Building the project..."
npm run build

# Create .nojekyll file
touch out/.nojekyll

# Initialize a git repository in the out directory
cd out
git init
git checkout -b main

# Add all files
git add .

# Commit
git commit -m "Deploy to GitHub Pages"

# Set the remote (replace with your own remote)
git remote add origin https://github.com/$GITHUB_USERNAME/$REPO_NAME.git

# Force push to the gh-pages branch
echo "🚀 Pushing to GitHub Pages..."
git push -f origin main:gh-pages

echo "✅ Successfully deployed to https://$GITHUB_USERNAME.github.io/$REPO_NAME/"
