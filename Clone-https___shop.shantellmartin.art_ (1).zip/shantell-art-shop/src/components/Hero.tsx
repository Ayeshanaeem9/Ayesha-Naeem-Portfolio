"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Hero() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const images = [
    {
      src: "https://ext.same-assets.com/3177054113/3425280857.jpeg",
      alt: "Shantell Martin creating a mural",
      title: "UNIQUE AND CREATIVE DESIGNS",
      subtitle: "SHANTELL APPAREL.",
      cta: { text: "EXPLORE NOW", href: "/apparel" }
    },
    {
      src: "https://ext.same-assets.com/4206116972/3411320790.jpeg",
      alt: "Shantell Martin artwork display",
      title: "THOUGHTFULLY BOLD",
      subtitle: "POSITIVELY INSPIRING.",
      cta: { text: "EXPLORE ALL", href: "/artwork" }
    },
    {
      src: "https://ext.same-assets.com/560874128/874209533.jpeg",
      alt: "Shantell Martin line artwork",
      title: "ARE YOU YOU",
      subtitle: "WEAR YOUR ART",
      cta: { text: "DISCOVER MORE", href: "/about" }
    }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [images.length])

  return (
    <section className="relative overflow-hidden h-[70vh] md:h-[80vh] lg:h-[90vh]">
      {images.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentIndex ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
        >
          <div className="relative h-full w-full">
            <Image
              src={image.src}
              alt={image.alt}
              fill
              className="object-cover object-center"
              priority={index === 0}
            />
            <div className="absolute inset-0 bg-black bg-opacity-40" />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
              <p className="text-white text-sm md:text-base uppercase tracking-widest mb-2">
                {image.title}
              </p>
              <h1 className="text-white text-4xl md:text-6xl lg:text-7xl font-bold uppercase tracking-tight mb-8">
                {image.subtitle}
              </h1>
              <Button asChild className="uppercase tracking-wide bg-white text-black hover:bg-gray-100 hover:text-black">
                <Link href={image.cta.href}>{image.cta.text}</Link>
              </Button>
            </div>
          </div>
        </div>
      ))}
      <div className="absolute bottom-6 left-0 right-0 flex justify-center space-x-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-2 w-2 rounded-full ${
              index === currentIndex ? "bg-white" : "bg-white/50"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  )
}
