import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t py-12 mt-24 bg-white">
      <div className="container grid grid-cols-1 gap-8 md:grid-cols-4">
        <div className="space-y-4">
          <h3 className="text-lg font-bold uppercase tracking-wide">Original Art</h3>
          <p className="text-sm text-muted-foreground">
            The relationship between an artist and collector should be just that... a relationship.
          </p>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-bold uppercase tracking-wide">Quick Links</h3>
          <ul className="space-y-2">
            <li>
              <Link href="/about" className="text-sm hover:underline">
                About
              </Link>
            </li>
            <li>
              <Link href="/artwork/prints" className="text-sm hover:underline">
                Prints
              </Link>
            </li>
            <li>
              <Link href="/apparel" className="text-sm hover:underline">
                Apparel
              </Link>
            </li>
            <li>
              <Link href="/collaborations" className="text-sm hover:underline">
                Collaborations
              </Link>
            </li>
            <li>
              <Link href="/exhibitions" className="text-sm hover:underline">
                Exhibitions
              </Link>
            </li>
          </ul>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-bold uppercase tracking-wide">Information</h3>
          <ul className="space-y-2">
            <li>
              <Link href="/privacy-policy" className="text-sm hover:underline">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link href="/terms-of-service" className="text-sm hover:underline">
                Terms of Service
              </Link>
            </li>
            <li>
              <Link href="/commissions" className="text-sm hover:underline">
                Commission Process
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-sm hover:underline">
                Contact
              </Link>
            </li>
          </ul>
        </div>
        <div className="space-y-4">
          <h3 className="text-lg font-bold uppercase tracking-wide">Follow Us</h3>
          <div className="flex space-x-4">
            <Link href="https://twitter.com" className="text-foreground hover:text-primary">
              <TwitterIcon className="h-5 w-5" />
              <span className="sr-only">Twitter</span>
            </Link>
            <Link href="https://instagram.com" className="text-foreground hover:text-primary">
              <InstagramIcon className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link href="https://facebook.com" className="text-foreground hover:text-primary">
              <FacebookIcon className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </Link>
            <Link href="https://youtube.com" className="text-foreground hover:text-primary">
              <YoutubeIcon className="h-5 w-5" />
              <span className="sr-only">YouTube</span>
            </Link>
          </div>
          <div className="mt-6">
            <h4 className="text-sm font-medium mb-2">Subscribe to our newsletter</h4>
            <div className="flex">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 rounded-l-md border border-r-0 border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground"
              />
              <button className="rounded-r-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground">
                Subscribe
              </button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Be the first to know about new collections and exhibitions.
            </p>
          </div>
        </div>
      </div>
      <div className="container mt-8 border-t pt-8">
        <div className="flex flex-col-reverse gap-4 md:flex-row md:items-center md:justify-between">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Shantell Martin. All rights reserved.
          </p>
          <div className="flex items-center space-x-2">
            <span className="rounded-md border px-2 py-1 text-xs">English</span>
            <span className="rounded-md border px-2 py-1 text-xs">USD $</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

function TwitterIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
    </svg>
  )
}

function InstagramIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  )
}

function FacebookIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  )
}

function YoutubeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  )
}
