import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AspectRatio } from "@/components/ui/aspect-ratio"
import { Card, CardContent } from "@/components/ui/card"

interface ArtworkProps {
  artwork: {
    id: string
    title: string
    price: string
    imageSrc: string
    imageAlt: string
    detailSrc?: string
  }
}

function ArtworkCard({ artwork }: ArtworkProps) {
  return (
    <Card className="overflow-hidden border-none bg-white shadow-sm transition-all hover:shadow-md">
      <CardContent className="p-0">
        <Link href={`/artwork/${artwork.id}`}>
          <div className="overflow-hidden">
            <AspectRatio ratio={1 / 1} className="bg-muted">
              <Image
                src={artwork.imageSrc}
                alt={artwork.imageAlt}
                fill
                className="object-cover object-center transition-transform hover:scale-105"
              />
            </AspectRatio>
          </div>
          <div className="p-4">
            <h3 className="line-clamp-1 text-base font-medium">{artwork.title}</h3>
            <p className="mt-1 text-sm">{artwork.price}</p>
          </div>
        </Link>
      </CardContent>
    </Card>
  )
}

export function FeaturedArtwork() {
  const featuredArtworks = [
    {
      id: "one-lithograph",
      title: "One (Lithograph)",
      price: "$500.00",
      imageSrc: "https://ext.same-assets.com/1089614442/3456456587.jpeg",
      imageAlt: "One Lithograph artwork by Shantell Martin",
      detailSrc: "https://ext.same-assets.com/2008200891/861606857.jpeg"
    },
    {
      id: "two-lithograph",
      title: "Two (Lithograph)",
      price: "$500.00",
      imageSrc: "https://ext.same-assets.com/581280838/4271405611.jpeg",
      imageAlt: "Two Lithograph artwork by Shantell Martin",
      detailSrc: "https://ext.same-assets.com/902569312/3057227048.jpeg"
    },
    {
      id: "three-lithograph",
      title: "Three (Lithograph)",
      price: "$500.00",
      imageSrc: "https://ext.same-assets.com/2761418991/3500861600.jpeg",
      imageAlt: "Three Lithograph artwork by Shantell Martin",
      detailSrc: "https://ext.same-assets.com/2611463085/3714510384.jpeg"
    },
    {
      id: "four-lithograph",
      title: "Four (Lithograph)",
      price: "$500.00",
      imageSrc: "https://ext.same-assets.com/1847617457/1041322322.jpeg",
      imageAlt: "Four Lithograph artwork by Shantell Martin",
      detailSrc: "https://ext.same-assets.com/4233648122/518648900.jpeg"
    },
    {
      id: "five-lithograph",
      title: "Five (Lithograph)",
      price: "$500.00",
      imageSrc: "https://ext.same-assets.com/3192702198/874570515.jpeg",
      imageAlt: "Five Lithograph artwork by Shantell Martin",
      detailSrc: "https://ext.same-assets.com/778484025/3196930716.jpeg"
    },
    {
      id: "six-lithograph",
      title: "Six (Lithograph)",
      price: "$500.00",
      imageSrc: "https://ext.same-assets.com/2612802310/2992305280.jpeg",
      imageAlt: "Six Lithograph artwork by Shantell Martin",
      detailSrc: "https://ext.same-assets.com/1763148113/806376802.jpeg"
    }
  ]

  return (
    <section className="py-12 md:py-16 lg:py-20">
      <div className="container">
        <div className="mb-8 flex flex-col items-center text-center">
          <h2 className="text-3xl font-bold uppercase tracking-tight">For Your Wall</h2>
          <p className="mt-4 max-w-[58rem] text-muted-foreground">
            Shantell Martin uses an ink marker to create small personal sketches, large-scale murals,
            and live drawings that explore themes of identity, creativity, and imagination.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredArtworks.map((artwork) => (
            <ArtworkCard key={artwork.id} artwork={artwork} />
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <Button asChild className="uppercase tracking-wide">
            <Link href="/artwork/prints">View All Prints</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
