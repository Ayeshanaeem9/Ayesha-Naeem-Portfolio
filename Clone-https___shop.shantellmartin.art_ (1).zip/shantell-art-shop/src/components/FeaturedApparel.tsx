import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AspectRatio } from "@/components/ui/aspect-ratio"
import { Card, CardContent } from "@/components/ui/card"

interface ApparelProps {
  apparel: {
    id: string
    title: string
    price: string
    imageSrc: string
    imageAlt: string
    detailSrc?: string
  }
}

function ApparelCard({ apparel }: ApparelProps) {
  return (
    <Card className="overflow-hidden border-none bg-white shadow-sm transition-all hover:shadow-md">
      <CardContent className="p-0">
        <Link href={`/apparel/${apparel.id}`}>
          <div className="overflow-hidden">
            <AspectRatio ratio={1 / 1} className="bg-muted">
              <Image
                src={apparel.imageSrc}
                alt={apparel.imageAlt}
                fill
                className="object-cover object-center transition-transform hover:scale-105"
              />
            </AspectRatio>
          </div>
          <div className="p-4">
            <h3 className="line-clamp-1 text-base font-medium">{apparel.title}</h3>
            <p className="mt-1 text-sm">{apparel.price}</p>
          </div>
        </Link>
      </CardContent>
    </Card>
  )
}

export function FeaturedApparel() {
  const featuredApparel = [
    {
      id: "bird-boat-crew",
      title: "Shantell Crew - Bird Boat",
      price: "$180.00",
      imageSrc: "https://ext.same-assets.com/366456665/2977527439.jpeg",
      imageAlt: "Shantell Crew - Bird Boat",
      detailSrc: "https://ext.same-assets.com/2594454852/4148158035.jpeg"
    },
    {
      id: "la-tshirt",
      title: "Shantell T-Shirt - LA",
      price: "$120.00",
      imageSrc: "https://ext.same-assets.com/3893958576/2062409029.jpeg",
      imageAlt: "Shantell T-Shirt - LA - Limited Edition T",
      detailSrc: "https://ext.same-assets.com/2412062548/1543433670.jpeg"
    },
    {
      id: "are-you-you-tshirt",
      title: "Shantell T-Shirt - Are You You",
      price: "$60.00",
      imageSrc: "https://ext.same-assets.com/2952837774/3399044965.jpeg",
      imageAlt: "Shantell T-Shirt - Are You You",
      detailSrc: "https://ext.same-assets.com/3568320878/1495562367.jpeg"
    }
  ]

  return (
    <section className="py-12 md:py-16 lg:py-20 bg-muted">
      <div className="container">
        <div className="mb-8 flex flex-col items-center text-center">
          <h2 className="text-3xl font-bold uppercase tracking-tight">Wear Your Art</h2>
          <p className="mt-4 max-w-[58rem] text-muted-foreground">
            Apparel crafted for expression, featuring Shantell Martin's distinctive line artwork
          </p>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredApparel.map((apparel) => (
            <ApparelCard key={apparel.id} apparel={apparel} />
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <Button asChild className="uppercase tracking-wide">
            <Link href="/apparel">View All Apparel</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
