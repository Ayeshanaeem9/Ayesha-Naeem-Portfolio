import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function AboutSection() {
  return (
    <section className="py-12 md:py-16 lg:py-20 bg-black text-white">
      <div className="container">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
          <div className="flex flex-col space-y-8">
            <div>
              <h2 className="text-2xl font-bold uppercase tracking-wide md:text-3xl">
                ARE YOU YOU
              </h2>
            </div>
            <div className="space-y-4">
              <p>
                Shantell Martin is a public speaker, curator, philosopher, cultural facilitator, teacher,
                choreographer, songwriter, performer, and more. From fashion and celebrity collaborations to
                positions at MIT Media Lab, NYU Tisch ITP, Columbia University's Brown Institute, and
                choreographing a ballet at the Boston Ballet, Shantell's drawn LINE constantly evolves.
              </p>
              <p>
                Creating new connections between fine art, education, design, philosophy, and technology,
                Shantell explores themes such as intersectionality, identity, and play.
              </p>
              <p>
                In addition to prestigious solo shows at some of the most renowned art institutions including
                the 92Y Gallery in New York City, the iconic Albright Knox Gallery, and the New Britain Museum
                of American Art, Shantell has carved a path for herself that is as much intellectual as a
                producer and visual artist.
              </p>
            </div>
            <div>
              <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-black uppercase tracking-wide">
                <Link href="/about">More about Shantell</Link>
              </Button>
            </div>
          </div>
          <div className="relative mt-8 lg:mt-0">
            <div className="relative aspect-[4/5] overflow-hidden rounded-md">
              <Image
                src="https://ext.same-assets.com/532912459/2586677189.jpeg"
                alt="Shantell Martin portrait"
                fill
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 aspect-square w-32 md:-bottom-8 md:-left-8 md:w-40 lg:w-48">
              <Image
                src="https://ext.same-assets.com/22451986/977723821.jpeg"
                alt="Shantell Martin line drawing"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
