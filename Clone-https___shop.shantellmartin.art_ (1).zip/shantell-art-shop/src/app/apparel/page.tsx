import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function ApparelPage() {
  const apparel = [
    {
      id: "bird-boat-crew",
      title: "Shantell Crew - Bird Boat",
      price: "$180.00",
      imageSrc: "https://ext.same-assets.com/366456665/2977527439.jpeg",
      imageAlt: "Shantell Crew - Bird Boat",
      detailSrc: "https://ext.same-assets.com/2594454852/4148158035.jpeg",
      category: "sweatshirts"
    },
    {
      id: "la-tshirt",
      title: "Shantell T-Shirt - LA",
      price: "$120.00",
      imageSrc: "https://ext.same-assets.com/3893958576/2062409029.jpeg",
      imageAlt: "Shantell T-Shirt - LA - Limited Edition T",
      detailSrc: "https://ext.same-assets.com/2412062548/1543433670.jpeg",
      category: "t-shirts"
    },
    {
      id: "are-you-you-tshirt",
      title: "Shantell T-Shirt - Are You You",
      price: "$60.00",
      imageSrc: "https://ext.same-assets.com/2952837774/3399044965.jpeg",
      imageAlt: "Shantell T-Shirt - Are You You",
      detailSrc: "https://ext.same-assets.com/3568320878/1495562367.jpeg",
      category: "t-shirts"
    },
    {
      id: "wonder-tshirt",
      title: "Shantell T-Shirt - Wonder",
      price: "$60.00",
      imageSrc: "https://ext.same-assets.com/1228397687/4264658934.jpeg",
      imageAlt: "Shantell T-Shirt - Wonder - Limited Edition T",
      category: "t-shirts"
    },
    {
      id: "one-day-tshirt",
      title: "Shantell T-Shirt - One Day",
      price: "$60.00",
      imageSrc: "https://ext.same-assets.com/963359242/4001134307.jpeg",
      imageAlt: "Shantell T-Shirt - One Day - Limited Edition T",
      category: "t-shirts"
    },
    {
      id: "shantell-hoodie",
      title: "Shantell Hoodie - Black",
      price: "$180.00",
      imageSrc: "https://ext.same-assets.com/4206116972/3411320790.jpeg",
      imageAlt: "Shantell Hoodie - Black",
      category: "hoodies"
    }
  ]

  return (
    <div className="container py-12 md:py-16">
      <div className="space-y-8">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl font-bold uppercase tracking-tight md:text-5xl">Shantell Apparel</h1>
          <p className="mx-auto max-w-3xl text-xl text-muted-foreground">
            Wear your art with Shantell Martin's signature line work on premium apparel
          </p>
        </div>

        <section className="py-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">All Apparel</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">Filter</Button>
              <select className="rounded-md border border-input px-3 py-1 text-sm">
                <option value="featured">Featured</option>
                <option value="newest">Newest</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 py-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {apparel.map((item) => (
              <Link
                key={item.id}
                href={`/apparel/${item.id}`}
                className="group overflow-hidden rounded-lg border bg-background shadow-sm transition-all hover:shadow-md"
              >
                <div className="aspect-[1/1] overflow-hidden bg-muted">
                  <Image
                    src={item.imageSrc}
                    alt={item.imageAlt}
                    width={400}
                    height={400}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="line-clamp-1 text-base font-medium">{item.title}</h3>
                  <p className="mt-1 text-sm">{item.price}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="rounded-lg bg-black p-8 text-white md:p-12">
          <div className="grid gap-6 md:grid-cols-2 md:gap-12">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold uppercase">Thoughtfully Bold</h2>
              <p>
                Each piece of Shantell Martin apparel is crafted with the same attention to detail and
                artistic vision as her large-scale artworks. The clothing becomes a canvas for her
                signature black and white linework, allowing you to carry a piece of her artistic
                expression with you.
              </p>
              <div className="pt-4">
                <Button asChild variant="outline" className="uppercase tracking-wide border-white text-white hover:bg-white hover:text-black">
                  <Link href="/about">About The Artist</Link>
                </Button>
              </div>
            </div>
            <div className="relative aspect-square overflow-hidden rounded-md mt-6 md:mt-0">
              <Image
                src="https://ext.same-assets.com/532912459/2586677189.jpeg"
                alt="Shantell Martin portrait"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        <section className="py-8">
          <div className="space-y-4 text-center">
            <h2 className="text-3xl font-bold">Limited Edition Releases</h2>
            <p className="mx-auto max-w-3xl text-muted-foreground">
              Sign up for our newsletter to be the first to know about new apparel drops
            </p>
            <div className="mx-auto mt-6 max-w-md">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 rounded-l-md border border-r-0 border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground"
                />
                <Button className="rounded-l-none">Subscribe</Button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
