import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function ArtworkPage() {
  const collections = [
    {
      id: "prints",
      title: "Prints",
      description: "Limited edition prints featuring Shantell's signature line work",
      image: "https://ext.same-assets.com/1089614442/3456456587.jpeg",
      link: "/artwork/prints"
    },
    {
      id: "collections",
      title: "Collections",
      description: "Curated collections of artwork grouped by theme or series",
      image: "https://ext.same-assets.com/3116663817/3159625203.jpeg",
      link: "/artwork/collections"
    },
    {
      id: "commissions",
      title: "Commissions",
      description: "Commission a custom piece of artwork for your space",
      image: "https://ext.same-assets.com/590733649/1316682636.jpeg",
      link: "/artwork/commissions"
    },
    {
      id: "exhibitions",
      title: "Exhibitions",
      description: "Past and upcoming exhibitions featuring Shantell's work",
      image: "https://ext.same-assets.com/4144921184/1832627857.jpeg",
      link: "/artwork/exhibitions"
    }
  ]

  return (
    <div className="container py-12 md:py-16">
      <div className="space-y-8">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl font-bold uppercase tracking-tight md:text-5xl">Artwork</h1>
          <p className="mx-auto max-w-3xl text-xl text-muted-foreground">
            Explore Shantell Martin's distinctive black and white artwork, from limited edition
            prints to large-scale installations
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 py-8 md:grid-cols-2">
          {collections.map((collection) => (
            <Link
              key={collection.id}
              href={collection.link}
              className="group overflow-hidden rounded-lg border bg-background shadow-sm transition-all hover:shadow-md"
            >
              <div className="aspect-[3/2] overflow-hidden">
                <Image
                  src={collection.image}
                  alt={collection.title}
                  width={600}
                  height={400}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h2 className="text-2xl font-bold">{collection.title}</h2>
                <p className="mt-2 text-muted-foreground">{collection.description}</p>
                <div className="mt-4">
                  <span className="inline-flex items-center text-sm font-medium underline">
                    Explore {collection.title}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <section className="rounded-lg bg-muted p-8 md:p-12">
          <div className="grid gap-6 md:grid-cols-2 md:gap-12">
            <div>
              <h2 className="text-2xl font-bold mb-4">ARE YOU YOU</h2>
              <p className="mb-4">
                Shantell Martin's signature phrase captures the essential questions that drive her
                work: Who are you, and are you being true to yourself?
              </p>
              <p className="mb-6">
                This philosophical inquiry runs through all of her work, from small personal sketches
                to room-sized installations, inviting viewers to consider their own identities and
                connections to the world around them.
              </p>
              <Button asChild className="uppercase tracking-wide">
                <Link href="/about">Learn More</Link>
              </Button>
            </div>
            <div className="relative aspect-square overflow-hidden rounded-md">
              <Image
                src="https://ext.same-assets.com/4005316876/3900223535.jpeg"
                alt="ARE YOU YOU artwork"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        <section className="py-8">
          <div className="space-y-4 text-center">
            <h2 className="text-3xl font-bold">Commission Artwork</h2>
            <p className="mx-auto max-w-3xl text-muted-foreground">
              Bring Shantell's distinctive black and white linework to your space with a custom commission
            </p>
            <div className="pt-4">
              <Button asChild>
                <Link href="/artwork/commissions">Learn More About Commissions</Link>
              </Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
