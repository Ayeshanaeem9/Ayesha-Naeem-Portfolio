import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="container py-12 md:py-16">
      <div className="mx-auto max-w-4xl space-y-12">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl font-bold uppercase tracking-tight md:text-5xl">About Shantell Martin</h1>
          <p className="text-xl text-muted-foreground">
            Artist, philosopher, collaborator, educator
          </p>
        </div>

        <div className="relative aspect-video overflow-hidden rounded-lg shadow-lg">
          <Image
            src="https://ext.same-assets.com/3177054113/3425280857.jpeg"
            alt="Shantell Martin working on a mural"
            fill
            className="object-cover"
            priority
          />
        </div>

        <div className="space-y-6 text-lg">
          <p>
            Shantell Martin is a visual artist, known for her signature black and white drawings. Her work explores themes
            of identity, intersectionality, and human connection through expressive linework and wordplay.
          </p>

          <p>
            Martin's work is a meditation of lines; a language of characters, creatures and messages that invites viewers
            to share a role in the creative process. From early beginnings with live performance drawing in the mega clubs of
            Tokyo, to her trademark continuous line, Martin's diverse work navigates many worlds.
          </p>

          <h2 className="text-2xl font-bold mt-8">Background and Journey</h2>

          <p>
            Born in London, Martin moved to Japan after graduating from Central Saint Martins, where she developed her
            performance drawing skills in the Tokyo club scene. After five years in Japan, she relocated to New York City,
            where her career has flourished with collaborations and installations.
          </p>

          <p>
            In addition to prestigious solo shows at some of the most renowned art institutions including the 92Y Gallery in
            New York City, the iconic Albright Knox Gallery, and the New Britain Museum of American Art, Shantell has carved
            a path for herself that is as much intellectual as a producer and visual artist.
          </p>

          <h2 className="text-2xl font-bold mt-8">Education and Teaching</h2>

          <p>
            At the Brown Institute for Media Innovation, she created a large-scale wall installation and worked with the
            Institute's research group to explore how visual and computerized storytelling might influence media and
            technology innovation. At the NYU Tisch ITP (Interactive Telecommunications Program), she worked with her
            students to push the boundaries of storytelling, visual art, and technology.
          </p>

          <h2 className="text-2xl font-bold mt-8">Notable Collaborations</h2>

          <p>
            Martin has collaborated with institutions and brands including the New York City Ballet, The Whitney Museum,
            Tiffany & Co., Puma, Max Mara, and Vespa. Her work often appears in unexpected contexts, from performance
            spaces and galleries to apparel, sneakers, textiles, and even a Lexus concept car.
          </p>

          <div className="grid grid-cols-1 gap-6 pt-6 md:grid-cols-2">
            <div className="relative aspect-square overflow-hidden rounded-md">
              <Image
                src="https://ext.same-assets.com/532912459/2586677189.jpeg"
                alt="Shantell Martin portrait"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative aspect-square overflow-hidden rounded-md">
              <Image
                src="https://ext.same-assets.com/2609633424/3324464903.jpeg"
                alt="Shantell Martin artwork"
                fill
                className="object-cover"
              />
            </div>
          </div>

          <h2 className="text-2xl font-bold mt-8">Philosophy</h2>

          <p>
            "WHO ARE YOU? ARE YOU YOU?" These fundamental questions underpin Martin's practice. Her work invites viewers
            to consider their own identities through her expressive lines and distinctive visual vocabulary. By developing
            a unique visual language that responds to environmental and emotional cues, Martin explores the role of artist
            and creator as a mirror for others.
          </p>

          <h2 className="text-2xl font-bold mt-8">Current Work</h2>

          <p>
            Today, Martin continues to evolve her practice through large-scale installations, live drawing performances,
            and collaborations that bridge art, technology, design, and education. Her commitment to authenticity and
            personal exploration makes her a distinctive voice in contemporary art.
          </p>
        </div>

        <div className="flex justify-center pt-8">
          <Button asChild className="uppercase tracking-wide">
            <Link href="/artwork">Explore Artwork</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
