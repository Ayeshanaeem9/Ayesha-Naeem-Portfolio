import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function CollaborationsPage() {
  const collaborations = [
    {
      id: "moft",
      title: "Shantell Martin x MOFT",
      description: "A collaboration with MOFT on limited edition Snap Flow tablet stands featuring Shantell's distinctive line art",
      image: "https://ext.same-assets.com/3898792334/4047405126.png",
      link: "#",
      year: "2023"
    },
    {
      id: "uno",
      title: "UNO x Shantell Martin",
      description: "Special edition UNO Artiste Series card deck reimagined with Shantell's signature style",
      image: "https://ext.same-assets.com/946675274/677941279.jpeg",
      link: "#",
      year: "2022"
    },
    {
      id: "bad-ideas",
      title: "Bad Ideas - Vinyl & Screenprint",
      description: "Limited edition vinyl with signed screenprint collaboration with musicians",
      image: "https://ext.same-assets.com/2168046628/2023856768.jpeg",
      link: "#",
      year: "2023"
    },
    {
      id: "playing-cards",
      title: "Shantell Martin Playing Cards",
      description: "Custom designed playing cards featuring Shantell's artwork",
      image: "https://ext.same-assets.com/157605594/3478029915.jpeg",
      link: "#",
      year: "2021"
    },
    {
      id: "new-balance",
      title: "New Balance x Shantell Martin",
      description: "Limited edition footwear and apparel collection with New Balance",
      image: "https://ext.same-assets.com/4206116972/3411320790.jpeg",
      link: "#",
      year: "2020"
    },
    {
      id: "puma",
      title: "Puma x Shantell Martin",
      description: "Collaborative footwear and apparel collection with Puma",
      image: "https://ext.same-assets.com/532912459/2586677189.jpeg",
      link: "#",
      year: "2018"
    }
  ]

  const featuredCollaboration = {
    title: "Shantell Martin x The Whitney Museum Shop",
    description:
      "In collaboration with the Whitney Museum of American Art, Shantell Martin created a limited edition collection that brings her distinctive black and white line art to a range of products. The collection includes apparel, accessories, and home goods that reflect the artist's playful and thoughtful approach to art-making.",
    image: "https://ext.same-assets.com/520412286/3820339842.jpeg",
    link: "#"
  }

  return (
    <div className="container py-12 md:py-16">
      <div className="space-y-12">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl font-bold uppercase tracking-tight md:text-5xl">Collaborations</h1>
          <p className="mx-auto max-w-3xl text-xl text-muted-foreground">
            Shantell Martin works with brands and institutions to create unique, limited edition products and experiences
          </p>
        </div>

        <section className="rounded-lg bg-muted p-8 md:p-12">
          <div className="grid gap-8 md:grid-cols-2">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold">{featuredCollaboration.title}</h2>
              <p className="text-muted-foreground">{featuredCollaboration.description}</p>
              <div className="pt-4">
                <Button asChild className="uppercase tracking-wide">
                  <Link href={featuredCollaboration.link}>View Collection</Link>
                </Button>
              </div>
            </div>
            <div className="relative aspect-video overflow-hidden rounded-lg">
              <Image
                src={featuredCollaboration.image}
                alt={featuredCollaboration.title}
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        <section>
          <h2 className="mb-8 text-2xl font-bold">All Collaborations</h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {collaborations.map((collab) => (
              <div
                key={collab.id}
                className="group overflow-hidden rounded-lg border bg-background shadow-sm transition-all hover:shadow-md"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <Image
                    src={collab.image}
                    alt={collab.title}
                    width={600}
                    height={450}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <div className="mb-2 text-sm text-muted-foreground">{collab.year}</div>
                  <h3 className="mb-2 text-xl font-bold">{collab.title}</h3>
                  <p className="mb-4 text-muted-foreground">{collab.description}</p>
                  <Link href={collab.link} className="inline-flex items-center text-sm font-medium underline">
                    View Collaboration
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-lg bg-black p-8 text-white md:p-12">
          <div className="space-y-4 text-center">
            <h2 className="text-3xl font-bold">Collaborate with Shantell Martin</h2>
            <p className="mx-auto max-w-3xl">
              Shantell Martin is open to select collaboration opportunities with brands and institutions.
              If you're interested in exploring a potential partnership, please get in touch.
            </p>
            <div className="pt-4">
              <Button asChild variant="outline" className="uppercase tracking-wide border-white text-white hover:bg-white hover:text-black">
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
