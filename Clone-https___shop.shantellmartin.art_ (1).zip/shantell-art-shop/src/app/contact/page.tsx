"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function ContactPage() {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormState((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
      setFormState({
        name: "",
        email: "",
        subject: "",
        message: ""
      })
    }, 1500)
  }

  return (
    <div className="container py-12 md:py-16">
      <div className="mx-auto max-w-3xl space-y-8">
        <div className="space-y-4 text-center">
          <h1 className="text-4xl font-bold uppercase tracking-tight md:text-5xl">Contact Us</h1>
          <p className="text-xl text-muted-foreground">
            Get in touch with questions about artwork, commissions, or collaborations
          </p>
        </div>

        {isSubmitted ? (
          <div className="rounded-lg bg-green-50 p-8 text-center">
            <h2 className="text-2xl font-bold text-green-900">Thank You!</h2>
            <p className="mt-2 text-green-800">
              Your message has been sent successfully. We'll get back to you as soon as possible.
            </p>
            <Button
              className="mt-6"
              onClick={() => setIsSubmitted(false)}
            >
              Send Another Message
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <label htmlFor="name" className="text-sm font-medium">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={formState.name}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={formState.email}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="subject" className="text-sm font-medium">
                Subject
              </label>
              <select
                id="subject"
                name="subject"
                required
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={formState.subject}
                onChange={handleChange}
              >
                <option value="">Select a subject</option>
                <option value="artwork">Artwork inquiry</option>
                <option value="commission">Commission request</option>
                <option value="collaboration">Collaboration proposal</option>
                <option value="press">Press inquiry</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="space-y-2">
              <label htmlFor="message" className="text-sm font-medium">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={6}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={formState.message}
                onChange={handleChange}
              />
            </div>
            <Button
              type="submit"
              className="w-full uppercase tracking-wide"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Sending..." : "Send Message"}
            </Button>
          </form>
        )}

        <div className="pt-12 space-y-6">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div className="space-y-2 text-center">
              <h3 className="text-lg font-bold uppercase">Studio</h3>
              <p className="text-muted-foreground">
                New York, NY
                <br />
                United States
              </p>
            </div>
            <div className="space-y-2 text-center">
              <h3 className="text-lg font-bold uppercase">Email</h3>
              <p className="text-muted-foreground">
                info@shantellmartin.art
                <br />
                press@shantellmartin.art
              </p>
            </div>
            <div className="space-y-2 text-center">
              <h3 className="text-lg font-bold uppercase">Social</h3>
              <p className="text-muted-foreground">
                @shantell_martin
                <br />
                Follow on Instagram
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
